-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: emergency response
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Emergency Call`
--

DROP TABLE IF EXISTS `Emergency Call`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Emergency Call` (
  `call_id` int NOT NULL,
  `caller name` varchar(45) NOT NULL,
  `time of call` datetime NOT NULL,
  `location of emergency` varchar(100) NOT NULL,
  `nature of emergency` varchar(45) NOT NULL,
  `dispatchID` int NOT NULL,
  PRIMARY KEY (`call_id`),
  KEY `dispatch-id_idx` (`dispatchID`),
  CONSTRAINT `dispatch-id` FOREIGN KEY (`dispatchID`) REFERENCES `Ambulance Dispatch` (`Dispatch ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Emergency Call`
--

LOCK TABLES `Emergency Call` WRITE;
/*!40000 ALTER TABLE `Emergency Call` DISABLE KEYS */;
INSERT INTO `Emergency Call` VALUES (1,'John Doe','2024-03-24 12:30:00','101 Main St','Cardiac Arrest',1),(2,'Jane Smith','2024-03-24 13:00:00','202 Oak Ave','Stroke',2),(3,'Michael Brown','2024-03-24 13:30:00','303 Pine Rd','Severe Allergic Reaction',3),(4,'Linda Green','2024-03-24 14:00:00','404 Elm Dr','Traumatic Injury',4),(5,'Chris Johnson','2024-03-24 14:30:00','505 Cedar Ln','Breathing Difficulty',5),(6,'Alex Kim','2024-03-24 15:00:00','606 Maple St','Severe Bleeding',6),(7,'Sam Lee','2024-03-24 15:30:00','707 Oak St','Burns',7),(8,'Emily Davis','2024-03-24 16:00:00','808 Pine Knoll','Poisoning',8),(9,'David Smith','2024-03-24 16:30:00','909 Cedar Ave','Hypothermia',9),(10,'Sophia Johnson','2024-03-24 17:00:00','1010 Birch Rd','Heat Stroke',10),(11,'Emma Wilson','2024-03-24 17:30:00','1111 Elm St','High Fever',11),(12,'Olivia Brown','2024-03-24 18:00:00','1212 Chestnut St','Seizure',12),(13,'Ava Garcia','2024-03-24 18:30:00','1313 Walnut St','Drowning',13),(14,'Isabella Martinez','2024-03-24 19:00:00','1414 Maple Ave','Electric Shock',14),(15,'Mia Anderson','2024-03-24 19:30:00','1515 Pine St','Choking',15),(16,'Amelia Thomas','2024-03-24 20:00:00','1616 Oak Rd','Drug Overdose',16),(17,'Harper Rodriguez','2024-03-24 20:30:00','1717 Birch Blvd','Asthma Attack',17),(18,'Ella Wilson','2024-03-24 21:00:00','1818 Cedar Path','Diabetic Emergency',18),(19,'Avery Martinez','2024-03-24 21:30:00','1919 Elm Lane','Fracture',19),(20,'Scarlett Anderson','2024-03-24 22:00:00','2020 Maple Dr','Appendicitis',20);
/*!40000 ALTER TABLE `Emergency Call` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 20:08:39
