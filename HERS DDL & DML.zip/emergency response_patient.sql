-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: emergency response
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `patient_ID` int NOT NULL,
  `Name` varchar(45) NOT NULL,
  `DOB` date NOT NULL,
  `Gender` varchar(45) NOT NULL,
  `Contactinfo` int NOT NULL,
  `conditiononarrival` varchar(45) NOT NULL,
  `arrivaltime` datetime NOT NULL,
  PRIMARY KEY (`patient_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (101,'John Doe','1985-07-22','Male',5551001,'Stable','2024-03-24 08:15:00'),(102,'Jane Smith','1990-05-14','Female',5551002,'Critical','2024-03-24 09:20:00'),(103,'Alex Johnson','1976-11-08','Non-binary',5551003,'Serious','2024-03-24 10:45:00'),(104,'Chris Lee','1983-02-19','Male',5551004,'Stable','2024-03-24 11:30:00'),(105,'Pat Kim','1995-03-25','Female',5551005,'Minor','2024-03-24 12:05:00'),(106,'Sam Morgan','1988-08-30','Male',5551006,'Moderate','2024-03-24 12:45:00'),(107,'Luisa Chen','1992-01-16','Female',5551007,'Serious','2024-03-24 13:15:00'),(108,'Raj Patel','1975-12-09','Male',5551008,'Critical','2024-03-24 14:00:00'),(109,'Emily Wright','1980-04-26','Female',5551009,'Stable','2024-03-24 14:30:00'),(110,'Mohamed Al-Farsi','1993-07-05','Male',5551010,'Minor','2024-03-24 15:00:00'),(111,'Clara Rodriguez','1987-09-12','Female',5551011,'Moderate','2024-03-24 15:35:00'),(112,'Omar Khan','1978-03-22','Male',5551012,'Critical','2024-03-24 16:10:00'),(113,'Nina Petrova','1981-11-30','Female',5551013,'Serious','2024-03-24 16:45:00'),(114,'Yuto Takahashi','1994-06-18','Male',5551014,'Stable','2024-03-24 17:20:00'),(115,'Isabella Rossi','1989-08-08','Female',5551015,'Minor','2024-03-24 18:00:00'),(116,'Lucas Smith','1974-02-28','Male',5551016,'Moderate','2024-03-24 18:30:00'),(117,'Sophia Johnson','1996-12-14','Female',5551017,'Serious','2024-03-24 19:05:00'),(118,'Ethan Williams','1984-10-03','Male',5551018,'Critical','2024-03-24 19:40:00'),(119,'Olivia Brown','1979-01-25','Female',5551019,'Stable','2024-03-24 20:15:00'),(120,'Mason Miller','1991-05-09','Male',5551020,'Minor','2024-03-24 20:50:00');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 20:08:39
