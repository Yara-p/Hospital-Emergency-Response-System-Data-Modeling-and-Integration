-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: emergency response
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `er admission`
--

DROP TABLE IF EXISTS `er admission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `er admission` (
  `admissionID` int NOT NULL,
  `time` datetime NOT NULL,
  `reason` varchar(45) NOT NULL,
  `patientID` int NOT NULL,
  PRIMARY KEY (`admissionID`),
  KEY `patientID_idx` (`patientID`),
  CONSTRAINT `pAID` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patient_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `er admission`
--

LOCK TABLES `er admission` WRITE;
/*!40000 ALTER TABLE `er admission` DISABLE KEYS */;
INSERT INTO `er admission` VALUES (71,'2024-03-25 08:30:00','Chest pain',101),(72,'2024-03-25 09:45:00','Shortness of breath',105),(73,'2024-03-25 10:15:00','Severe headache',103),(74,'2024-03-25 11:00:00','Abdominal pain',108),(75,'2024-03-25 12:30:00','Fractured limb',112),(76,'2024-03-25 13:45:00','Laceration',101),(77,'2024-03-25 14:10:00','Burns',115),(78,'2024-03-25 15:25:00','Allergic reaction',118),(79,'2024-03-25 16:40:00','Asthma attack',120),(80,'2024-03-25 17:55:00','Chest pain',104),(81,'2024-03-25 18:05:00','Severe headache',107),(82,'2024-03-25 19:15:00','Shortness of breath',110),(83,'2024-03-25 20:30:00','Abdominal pain',113),(84,'2024-03-25 21:45:00','Fractured limb',116),(85,'2024-03-25 22:50:00','Laceration',119),(86,'2024-03-25 23:05:00','Burns',102),(87,'2024-03-26 00:10:00','Allergic reaction',106),(88,'2024-03-26 01:20:00','Asthma attack',109),(89,'2024-03-26 02:35:00','Chest pain',111),(90,'2024-03-26 03:40:00','Severe headache',114);
/*!40000 ALTER TABLE `er admission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 20:08:38
