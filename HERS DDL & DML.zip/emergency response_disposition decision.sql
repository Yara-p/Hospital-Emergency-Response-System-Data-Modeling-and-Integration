-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: emergency response
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `disposition decision`
--

DROP TABLE IF EXISTS `disposition decision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disposition decision` (
  `decisionID` int NOT NULL,
  `time` datetime NOT NULL,
  `reason` varchar(45) NOT NULL,
  `outcome` varchar(45) NOT NULL,
  `ID` int NOT NULL,
  `patientID` int NOT NULL,
  PRIMARY KEY (`decisionID`),
  KEY `ID_idx` (`ID`),
  KEY `PatientID_idx` (`patientID`),
  CONSTRAINT `id_er` FOREIGN KEY (`ID`) REFERENCES `ER Physician` (`ID`),
  CONSTRAINT `patientid_dis` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patient_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disposition decision`
--

LOCK TABLES `disposition decision` WRITE;
/*!40000 ALTER TABLE `disposition decision` DISABLE KEYS */;
INSERT INTO `disposition decision` VALUES (1,'2024-03-09 23:38:43','Recovered','Discharge',1101,114),(2,'2024-03-21 23:38:43','Improved','Continue Observation',1107,101),(3,'2024-03-17 23:38:43','Worsened','Transfer to a higher-level hospital',1111,113),(4,'2024-03-15 23:38:43','Worsened','Transfer to a higher-level hospital',1111,118),(5,'2024-02-23 23:38:43','Improved','Continue Observation',1112,116),(6,'2024-03-13 23:38:43','Recovered','Discharge',1107,104),(7,'2024-03-02 23:38:43','Unchanged','Transfer to another department',1111,105),(8,'2024-03-06 23:38:43','Unchanged','Continue Observation',1112,115),(9,'2024-02-23 23:38:43','Unchanged','Continue Observation',1117,108),(10,'2024-03-09 23:38:43','Unchanged','Transfer to another department',1107,117),(11,'2024-03-11 23:38:43','Unchanged','Continue Observation',1107,103),(12,'2024-03-02 23:38:43','Unchanged','Continue Observation',1102,119),(13,'2024-03-12 23:38:43','Unchanged','Transfer to another department',1111,106),(14,'2024-03-06 23:38:43','Unchanged','Transfer to another department',1116,120),(15,'2024-03-06 23:38:43','Recovered','Discharge',1118,111),(16,'2024-03-04 23:38:43','Unchanged','Continue Observation',1119,102),(17,'2024-03-04 23:38:43','Recovered','Discharge',1109,109),(18,'2024-03-03 23:38:43','Improved','Transfer to another department',1108,107),(19,'2024-02-23 23:38:43','Recovered','Discharge',1108,112),(20,'2024-02-26 23:38:43','Unchanged','Transfer to another department',1101,110);
/*!40000 ALTER TABLE `disposition decision` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 20:08:39
