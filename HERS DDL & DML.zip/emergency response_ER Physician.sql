-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: emergency response
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ER Physician`
--

DROP TABLE IF EXISTS `ER Physician`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ER Physician` (
  `ID` int NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Specialty` varchar(45) NOT NULL,
  `shift` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ER Physician`
--

LOCK TABLES `ER Physician` WRITE;
/*!40000 ALTER TABLE `ER Physician` DISABLE KEYS */;
INSERT INTO `ER Physician` VALUES (1100,'Linda Green','Emergency Medicine','Night'),(1101,'Amelia Thomas','Neurology','Afternoon'),(1102,'Michael Brown','Orthopedics','Afternoon'),(1103,'Chris Johnson','Pediatrics','Night'),(1104,'John Doe','Neurology','Afternoon'),(1105,'Scarlett Anderson','Family Medicine','Night'),(1106,'Jane Smith','Emergency Medicine','Morning'),(1107,'Ella Wilson','Radiology','Night'),(1108,'Mia Anderson','Radiology','Afternoon'),(1109,'David Smith','Family Medicine','Afternoon'),(1110,'Sam Lee','Orthopedics','Afternoon'),(1111,'Ava Garcia','Pediatrics','Night'),(1112,'Harper Rodriguez','Radiology','Night'),(1113,'Alex Kim','Radiology','Night'),(1114,'Sophia Johnson','Neurology','Morning'),(1115,'Emma Wilson','Neurology','Afternoon'),(1116,'Emily Davis','General Surgery','Night'),(1117,'Isabella Martinez','Radiology','Afternoon'),(1118,'Olivia Brown','Family Medicine','Morning'),(1119,'Avery Martinez','Radiology','Morning');
/*!40000 ALTER TABLE `ER Physician` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 20:08:39
