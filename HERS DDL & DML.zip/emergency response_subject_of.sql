-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: emergency response
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subject_of`
--

DROP TABLE IF EXISTS `subject_of`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subject_of` (
  `patientID` int NOT NULL,
  `callID` int NOT NULL,
  PRIMARY KEY (`patientID`,`callID`),
  KEY `callID_idx` (`callID`),
  CONSTRAINT `callID` FOREIGN KEY (`callID`) REFERENCES `Emergency Call` (`call_id`),
  CONSTRAINT `patient.id` FOREIGN KEY (`patientID`) REFERENCES `patient` (`patient_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_of`
--

LOCK TABLES `subject_of` WRITE;
/*!40000 ALTER TABLE `subject_of` DISABLE KEYS */;
INSERT INTO `subject_of` VALUES (101,1),(102,1),(120,1),(101,2),(102,2),(120,2),(101,3),(102,3),(120,3),(101,4),(102,4),(120,4),(101,5),(102,5),(120,5),(101,6),(102,6),(120,6),(101,7),(102,7),(116,7),(101,8),(102,8),(107,8),(101,9),(102,9),(120,9),(101,10),(102,10),(120,10),(101,11),(102,11),(120,11),(102,12),(108,12),(120,12),(101,13),(102,13),(120,13),(102,14),(106,14),(120,14),(101,15),(108,15),(120,15),(101,16),(102,16),(120,16),(101,17),(102,17),(120,17),(101,18),(102,18),(120,18),(101,19),(102,19),(120,19),(101,20),(102,20),(120,20);
/*!40000 ALTER TABLE `subject_of` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 20:08:38
